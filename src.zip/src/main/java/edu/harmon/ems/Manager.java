package edu.harmon.ems;

public class Manager extends Employee {

    public Manager(String firstName, String lastName, int age, Department department) {
        super(firstName, lastName, age, department);
    }

    @Override
    public String getRole() {
        return "Manager";
    }
}
