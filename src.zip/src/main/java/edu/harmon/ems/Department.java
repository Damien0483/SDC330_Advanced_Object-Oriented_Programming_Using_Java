package edu.harmon.ems;

public class Department {
    private String deptName;

    public Department() {}

    public Department(String deptName) {
        this.deptName = deptName;
    }

    public String getDeptName() {
        return deptName;
    }
}

