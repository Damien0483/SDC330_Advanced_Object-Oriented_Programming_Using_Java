package edu.harmon.ems;

public class Employee extends Person {

    private Department department;

    public Employee() {}

    public Employee(String firstName, String lastName, int age, Department department) {
        super(firstName, lastName, age);
        this.department = department;
    }

    @Override
    public String getRole() {
        return "Employee";
    }

    public Department getDepartment() {
        return department;
    }
}
