package edu.harmon.ems;

public abstract class Person {
    protected String firstName;
    protected String lastName;
    protected int age;

    public Person() {}

    public Person(String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public abstract String getRole();

    public String getFirstName() { return firstName; }
    public String getLastName() {return lastName; }
    public String getFullName() {return firstName + " " + lastName; }
    public int getAge() { return age; }
}

