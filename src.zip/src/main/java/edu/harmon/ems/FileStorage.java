package edu.harmon.ems;


import java.io.*;
import java.util.*;
import org.springframework.stereotype.Component;

@Component
public class FileStorage implements Storage {

    private final File file = new File("employees.txt");

    @Override
    public void save(Person person) {
        try (FileWriter fw = new FileWriter(file, true)) {
            fw.write(person.getRole() + "|" +
                     person.getFirstName() + "|" +
                     person.getLastName() + "|" +
                     person.getAge() + "|" +
                     ((Employee) person).getDepartment().getDeptName() +
                     "\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Person> loadAll() {
        List<Person> list = new ArrayList<>();

        if (!file.exists()) return list;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\|");

                String role = p[0];
                String first = p[1];
                String last = p[2];
                int age = Integer.parseInt(p[3]);
                Department dept = new Department(p[4]);

                Person person = role.equals("Manager")
                        ? new Manager(first, last, age, dept)
                        : new Employee(first, last, age, dept);

                list.add(person);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}

