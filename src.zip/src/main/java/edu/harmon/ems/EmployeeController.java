package edu.harmon.ems;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class EmployeeController {

    private final EmployeeService service;

    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    @GetMapping({"/", "/home"})
    public String home() {
        return "welcome";
    }

    @GetMapping("/form")
    public String showForm(Model model) {
        model.addAttribute("employeeForm", new EmployeeForm());
        return "form";
    }

    @PostMapping("/form")
    public String submitForm(@ModelAttribute EmployeeForm employeeForm) {
        service.addEmployee(employeeForm);
        return "redirect:/list";
    }

    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("employees", service.getAll());
        return "list";
    }
}

