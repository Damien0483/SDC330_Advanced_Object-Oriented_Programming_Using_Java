package edu.harmon.ems;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    private final Storage storage;

    public EmployeeService(Storage storage) {
        this.storage = storage;
    }

    public void addEmployee(EmployeeForm form) {
        Department dept = new Department(form.getDepartment());

        Person person = form.getType().equalsIgnoreCase("manager")
                ? new Manager(form.getFirstName(), form.getLastName(), form.getAge(), dept)
                : new Employee(form.getFirstName(), form.getLastName(), form.getAge(), dept);

        storage.save(person);
    }

    public List<Person> getAll() {
        return storage.loadAll();
    }
}

