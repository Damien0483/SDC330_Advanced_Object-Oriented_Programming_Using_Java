package edu.harmon.ems;

import java.util.List;

public interface Storage {
    void save(Person person);
    List<Person> loadAll();
}

