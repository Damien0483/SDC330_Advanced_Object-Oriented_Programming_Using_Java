/**********************************************************************************
Name: Damien Harmon
Date: April 05, 2026
Assignment: Week 3 Project
Description: Advanced Object-Oriented Programming with Java 
***********************************************************************************/
import java.util.ArrayList;
import java.util.List;

public class FundingLine extends AbstractAsset {

    private double allocatedAmount;
    private double spentAmount;
    private List<Project> projects;

    public FundingLine(String id, double allocatedAmount) {
        super(id);
        this.allocatedAmount = allocatedAmount;
        this.spentAmount = 0;
        this.projects = new ArrayList<>();
    }

    public void addProject(Project p) {
        projects.add(p);
    }

    public void spend(double amount) {
        spentAmount += amount;
    }

    @Override
    public String generateReport() {
        return "Funding Line Report\nID: " + id +
               "\nAllocated: $" + allocatedAmount +
               "\nSpent: $" + spentAmount +
               "\nRemaining: $" + (allocatedAmount - spentAmount);
    }
}

