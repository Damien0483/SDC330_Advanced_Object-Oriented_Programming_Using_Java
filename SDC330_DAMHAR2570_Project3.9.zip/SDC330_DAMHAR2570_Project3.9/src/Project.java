/**********************************************************************************
Name: Damien Harmon
Date: April 05, 2026
Assignment: Week 3 Project
Description: Advanced Object-Oriented Programming with Java 
***********************************************************************************/
import java.util.ArrayList;
import java.util.List;

public class Project extends AbstractAsset {

    private String name;
    private String description;
    private List<Equipment> equipmentList;

    public Project(String id, String name, String description) {
        super(id);
        this.name = name;
        this.description = description;
        this.equipmentList = new ArrayList<>();
    }

    public void addEquipment(Equipment eq) {
        equipmentList.add(eq);
    }

    @Override
    public String generateReport() {
        return "Project Report\nProject: " + name +
            "\nDescription: " + description +
            "\nEquipment Count: " + equipmentList.size();
    }
}

