/**
/**********************************************************************************
Name: Damien Harmon
Date: April 05, 2026
Assignment: Week 3 Project
Description: Advanced Object-Oriented Programming with Java 
***********************************************************************************/
public interface AssetReportable {
    String generateReport();
}

