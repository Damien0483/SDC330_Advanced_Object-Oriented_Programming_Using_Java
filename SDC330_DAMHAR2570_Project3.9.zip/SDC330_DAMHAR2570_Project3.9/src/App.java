/**********************************************************************************
Name: Damien Harmon
Date: April 05, 2026
Assignment: Week 3 Project
Description: Advanced Object-Oriented Programming with Java 
***********************************************************************************/
public class App {

    public static void main(String[] args) {

        Contract c1 = new Contract("N00019-24-C-0012", "Radar Modernization Contract");
        FundingLine f1 = new FundingLine("FL-2024-001", 500000);
        Project p1 = new Project("PJT-01", "Coastal Radar Upgrade", "Upgrade radar systems for coastal defense.");

        Equipment e1 = new Equipment("EQ-1001", "Radar Unit", "AN/SPY-6(V)1", 150000);

        c1.addFundingLine(f1);
        c1.addEquipment(e1);

        f1.addProject(p1);

        p1.addEquipment(e1);

        System.out.println(c1.generateReport());
        System.out.println(f1.generateReport());
        System.out.println(p1.generateReport());
        System.out.println(e1.generateReport());
    }
}

