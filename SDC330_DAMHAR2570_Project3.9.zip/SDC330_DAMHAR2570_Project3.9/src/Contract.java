/**********************************************************************************
Name: Damien Harmon
Date: April 05, 2026
Assignment: Week 3 Project
Description: Advanced Object-Oriented Programming with Java 
***********************************************************************************/
import java.util.ArrayList;
import java.util.List;

public class Contract extends AbstractAsset {

    private String awardDetails;
    private List<FundingLine> fundingLines;
    private List<Equipment> equipmentList;

    public Contract(String contractNumber, String awardDetails) {
        super(contractNumber);
        this.awardDetails = awardDetails;
        this.fundingLines = new ArrayList<>();
        this.equipmentList = new ArrayList<>();
    }

    public void addFundingLine(FundingLine fl) {
        fundingLines.add(fl);
    }

    public void addEquipment(Equipment eq) {
        equipmentList.add(eq);
    }

    @Override
    public String generateReport() {
        return "Contract Report\nContract Number: " + id +
            "\nAward Details: " + awardDetails +
            "\nFunding Lines: " + fundingLines.size() +
            "\nEquipment Count: " + equipmentList.size();
    }
}

