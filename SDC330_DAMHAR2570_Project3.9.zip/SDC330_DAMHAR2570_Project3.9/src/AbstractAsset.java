/**********************************************************************************
Name: Damien Harmon
Date: April 05, 2026
Assignment: Week 3 Project
Description: Advanced Object-Oriented Programming with Java 
***********************************************************************************/
public abstract class AbstractAsset implements AssetReportable {

    protected String id;

    public AbstractAsset(String id) {
        this.id = id;
    }

    public String getId() { return id; }

    @Override
    public abstract String generateReport();

    @Override
    public String toString() {
        return "ID: " + id;
    }
}

