/**********************************************************************************
Name: Damien Harmon
Date: April 05, 2026
Assignment: Week 3 Project
Description: Advanced Object-Oriented Programming with Java 
***********************************************************************************/
public class Equipment extends AbstractAsset {

    private String equipmentClass;
    private String specifications;
    private double cost;
    private Project project;

    public Equipment(String id, String equipmentClass, String specifications, double cost) {
        super(id);
        this.equipmentClass = equipmentClass;
        this.specifications = specifications;
        this.cost = cost;
    }

    public void assignProject(Project p) { this.project = p; }

    @Override
    public String generateReport() {
        return "Equipment Report\nID: " + id +
               "\nClass: " + equipmentClass +
               "\nSpecs: " + specifications +
               "\nCost: $" + cost +
               "\nProject: " + (project != null ? project.toString() : "None");
    }
}

