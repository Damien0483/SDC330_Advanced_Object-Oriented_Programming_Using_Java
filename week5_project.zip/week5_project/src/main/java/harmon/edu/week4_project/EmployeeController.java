package harmon.edu.week4_project;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * MVC controller handling navigation and CRUD operations for employees.
 */
@Controller
public class EmployeeController {

    private final EmployeeService service;

    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    @GetMapping({"/", "/home"})
    public String home() {
        return "welcome";
    }

    @GetMapping("/form")
    public String showForm(Model model) {
        model.addAttribute("employeeForm", new EmployeeForm());
        return "form";
    }

    @PostMapping("/form")
    public String submitForm(@ModelAttribute EmployeeForm employeeForm) {
        service.addEmployee(employeeForm);
        return "redirect:/list";
    }

    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("employees", service.getAll());
        return "list";
    }

    @GetMapping("/employee/{id}")
    public String viewEmployee(@PathVariable Long id, Model model) {
        Person person = service.getById(id)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));
        model.addAttribute("employee", person);
        return "detail";
    }

    @GetMapping("/employee/{id}/edit")
    public String editEmployee(@PathVariable Long id, Model model) {
        Person person = service.getById(id)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        EmployeeForm form = new EmployeeForm();
        form.setId(person.getId());
        form.setFirstName(person.getFirstName());
        form.setLastName(person.getLastName());
        form.setAge(person.getAge());
        form.setType(person.getRole());

        if (person instanceof Employee emp && emp.getDepartment() != null) {
            form.setDepartment(emp.getDepartment().getDeptName());
        }

        model.addAttribute("employeeForm", form);
        return "edit-form";
    }

    @PostMapping("/employee/{id}/edit")
    public String updateEmployee(@PathVariable Long id,
                                 @ModelAttribute EmployeeForm employeeForm) {
        employeeForm.setId(id);
        service.updateEmployee(employeeForm);
        return "redirect:/list";
    }

    @PostMapping("/employee/{id}/delete")
    public String deleteEmployee(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/list";
    }
}

