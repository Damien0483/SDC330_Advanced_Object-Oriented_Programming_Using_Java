package harmon.edu.week4_project;

import jakarta.persistence.Embeddable;

@Embeddable
public class Department {

    private String deptName;

    public Department() {}

    public Department(String deptName) {
        this.deptName = deptName;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
}

