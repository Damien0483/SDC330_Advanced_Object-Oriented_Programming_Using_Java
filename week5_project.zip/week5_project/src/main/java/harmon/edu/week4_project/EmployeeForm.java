package harmon.edu.week4_project;

/**
 * Simple form backing bean used to capture user input from the web form.
 * This is intentionally decoupled from the JPA entities.
 */
public class EmployeeForm {

    private Long id;          // used for update/delete
    private String firstName;
    private String lastName;
    private int age;
    private String department;
    private String type;      // "employee" or "manager"

    public EmployeeForm() {}

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getFirstName() { return firstName; }

    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }

    public void setLastName(String lastName) { this.lastName = lastName; }

    public int getAge() { return age; }

    public void setAge(int age) { this.age = age; }

    public String getDepartment() { return department; }

    public void setDepartment(String department) { this.department = department; }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }
}

