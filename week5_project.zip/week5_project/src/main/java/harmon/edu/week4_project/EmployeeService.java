package harmon.edu.week4_project;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service layer encapsulating business logic for managing employees and managers.
 */
@Service
public class EmployeeService {

    private final PersonRepository repository;

    public EmployeeService(PersonRepository repository) {
        this.repository = repository;
    }

    public Person addEmployee(EmployeeForm form) {
        Department dept = new Department(form.getDepartment());

        Person person = form.getType() != null &&
                        form.getType().equalsIgnoreCase("manager")
                ? new Manager(form.getFirstName(), form.getLastName(), form.getAge(), dept)
                : new Employee(form.getFirstName(), form.getLastName(), form.getAge(), dept);

        return repository.save(person);
    }

    public List<Person> getAll() {
        return repository.findAll();
    }

    public Optional<Person> getById(Long id) {
        return repository.findById(id);
    }

    public Person updateEmployee(EmployeeForm form) {
        Person existing = repository.findById(form.getId())
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        existing.setFirstName(form.getFirstName());
        existing.setLastName(form.getLastName());
        existing.setAge(form.getAge());

        if (existing instanceof Employee emp) {
            Department dept = emp.getDepartment();
            if (dept == null) {
                dept = new Department();
                emp.setDepartment(dept);
            }
            dept.setDeptName(form.getDepartment());
        }

        return repository.save(existing);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}

