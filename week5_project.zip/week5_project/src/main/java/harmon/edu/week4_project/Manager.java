package harmon.edu.week4_project;

import jakarta.persistence.Entity;

@Entity
public class Manager extends Employee {

    public Manager() {}

    public Manager(String firstName, String lastName, int age, Department department) {
        super(firstName, lastName, age, department);
    }

    @Override
    public String getRole() {
        return "Manager";
    }
}

