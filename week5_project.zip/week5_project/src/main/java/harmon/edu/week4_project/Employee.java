package harmon.edu.week4_project;

import jakarta.persistence.*;

@Entity
@Table(name = "employees")
public class Employee extends Person {

    @Embedded
    private Department department;

    public Employee() {}

    public Employee(String firstName, String lastName, int age, Department department) {
        super(firstName, lastName, age);
        this.department = department;
    }

    @Override
    public String getRole() {
        return "Employee";
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}

