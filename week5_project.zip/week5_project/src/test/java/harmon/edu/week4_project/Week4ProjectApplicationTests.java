package harmon.edu.week4_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
